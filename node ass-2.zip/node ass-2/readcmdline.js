let name=process.argv[2]
console.log("Hello" +" "+name)