const mode = process.env.USERNAME;
console.log( 'Hello'+" "+mode)