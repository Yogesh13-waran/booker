const fs = require('fs/promises')
const myFileWriter = async (fileName, fileContent) => {
    // write code here
    // dont chnage function name
     (fs.writeFile(fileName, fileContent))
}
const myFileReader = async (fileName) => {
    // write code here
    // dont chnage function name
    /*const data = fs.readFile(fileName, "utf-8", (err, data) => {
        if (err) {
            return err;
        }
        return data
    })
    data.then((fileData) => {
        console.log(fileData)
    })*/
    try {
        const data = await fs.readFile(fileName, { encoding: 'utf8' });
        console.log(data);
      } catch (err) {
        console.log(err);
      }
    }


const myFileUpdater = async (fileName, fileContent) => {
    // write code here
    // dont chnage function name
    fs.appendFile(fileName, fileContent)
}
const myFileDeleter = async (fileName) => {
    // write code here
    // dont chnage function name
     fs.unlink(fileName)
}
//(myFileWriter("File3.txt", "Hello"))
//(myFileReader("File1.txt"))
//myFileUpdater("File.txt", " World")
(myFileDeleter("File.txt"))
module.exports = { myFileWriter, myFileUpdater, myFileReader, myFileDeleter }
