const fs=require('fs')
fs.writeFile("ind.html",'<h1>Hello World</h1><p>This is YourName... Ravi </p>','utf-8',(err)=>{
    console.log(err)
})

const ht=require('http')
const h=ht.createServer();

h.on('request',(req,res)=>{
const stream=fs.createReadStream('ind.html','utf-8')
 res.writeHead(200,{'content-type':'html'})
stream.on("error",()=>{
    res.end('Page not found')
})
stream.pipe(res)
})
h.listen(5000,()=>console.log('server at 5000'))